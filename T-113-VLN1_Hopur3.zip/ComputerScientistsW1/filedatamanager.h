#ifndef FileDataManager
#define FileDataManager

class FileDataManager: public DataManager
{
public:

};

#endif // FileDataManager

